#!/bin/sh

# Hand off to the CMD
exec "$@"